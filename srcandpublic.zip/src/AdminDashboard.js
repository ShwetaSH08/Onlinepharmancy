import React from 'react';
import './AdminDashboard.css';
import logoImage from './images/log.png';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import Sidebar from './Sidebar';
import { Route, Switch } from 'react-router-dom';
import Login from './Login';

function AdminDashboard() {

  const logOut=()=>{
    if('user' in localStorage){
      localStorage.removeItem('user');
      window.location.href='/login';
    }
  }

  return (
    <div className='adminHomeDashboard'>
      <div className='adminHeader'>
        <div className="headerContainer" id="header">
                <img src={logoImage} alt="" className="adminHeader__logo" />
            {/* Logo */}
            
            {/* Navbar Options */}
            <div className="adminHeader__nav">
                <div className="adminHeader__optionBasket" onClick={logOut}>
                    <ExitToAppIcon className="header__optionLineOne"/>
                    <span className="adminHeader__optionLineOne">Logout</span>
                </div>                        
            </div>
        </div>
      </div>


      <div className='containerSub'>
        <div className='sideBar'>
            <Sidebar />
        </div>

        <div className='sideBarMainContent'>
          <Switch>
            <Route exact path="/login" component={Login} ></Route>
          </Switch>
        </div>
      </div>
    </div>
  )
}

export default AdminDashboard