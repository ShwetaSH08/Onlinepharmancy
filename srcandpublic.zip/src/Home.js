import React from 'react';
import './Home.css';
import Product from './Product.js';
import bgPic from './images/meds1.jpg';
import dolo from './images/dolo.webp';
import coughSyrup from './images/coughSyrup.png'
import moveImg from './images/moove.png';
import pokoPants from './images/pokopants.png';
import azy from './images/azithromycine.png';
import injection from './images/injection.png';
import minado from './images/minado.png';
import amo from './images/amo.png';
import horlicks from './images/horlicks.png';




function Home() {
    return (
        <div className="home">
            <div className="home__container">
                <img 
                    className="home__img"
                    src={bgPic} 
                    alt="" 
                />
            </div> 

            <div className="home__row">
                <Product 
                    id="12321341"
                    title="Paracetamol: Dolo 650mg, 15 tablets. Helps relieve pain and fever by blocking the release of certain chemical messengers responsible for fever and pain." 
                    price={25.36} 
                    image={dolo} 
                    rating={3}
                />

                <Product 
                    id="49538094"
                    title="Benadryl Cough Formula Syrup 100 ml contains Ammonium chloride, Diphenhydramine hydrochloride, Sodium citrate and ethanol used to treat cough." 
                    price={91.39} 
                    image={coughSyrup}
                    rating={5}
                />
            </div>

            <div className="home__row">
                <Product 
                    id="4903850"
                    title="Ointment using 100% ayurvedic ingredients, which penetrate deep inside to produce the warmth hence, it helps in relieving the pain."
                    price={199.96} 
                    image={moveImg}
                    rating={3} />

                <Product 
                    id="23445930"
                    title="MamyPokoPants, its stretchable thigh support prevents gaps between diaper and baby's thigh, hence prevents leakage."
                    price={98.96} 
                    image={pokoPants}
                    rating={3} />
                    
                <Product 
                    id="3254354345"
                    title="Azithromycin is an antibiotic medication used for the treatment of a number of bacterial infections. This includes middle ear infections, strep throat, pneumonia, traveler's diarrhea."
                    price={600.96} 
                    image={azy}
                    rating={3}
                />
            </div>


            <div className="home__row">
                <Product 
                    id="4903852"
                    title="Remdesivir is slowly injected into a vein of hospitalized COVID-19 patients over half an hour to two hours by a doctor or a nurse."
                    price={199.96} 
                    image={injection}
                    rating={3} />

                <Product 
                    id="23445030"
                    title="Minado Tablet 500mg. It is used in the treatment of migraine headaches and pain associated with conditions like rheumatoid arthritis, gout."
                    price={98.96} 
                    image={minado}
                    rating={3} />
                    
                <Product 
                    id="3254354345"
                    title="Amoxicillin is used to treat a wide variety of bacterial infections. This medication is a penicillin-type antibiotic. "
                    price={600.96} 
                    image={amo}
                    rating={3}
                />
            </div>



            <div className="home__row">
            <Product 
                    id="90829332"
                    title="Horlicks Diabetes Plus Vanilla 400 g Jar. Helps to manage blood sugar."
                    price={1098.96} 
                    image={horlicks}
                    rating={3}
                />
            </div>
        </div>
    )
}

export default Home;