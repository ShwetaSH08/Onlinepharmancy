import React, { useState, useEffect } from 'react';
import './Login.css';
import { Link, useHistory } from "react-router-dom";
// import { auth } from './firebase';
import logoImage from './images/log.png';

function Login() {
   
    const history = useHistory()
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState('user');

    useEffect(() => {
        if('user' in localStorage){
            // alert('You are already Signed In.')
            history.push('/')
        }
      });

      debugger;
    const signIn = e =>{
        e.preventDefault();

        // Firebase Login
        // auth.signInWithEmailAndPassword(email, password)
        // .then(auth => {
        //     history.push('/')
        // })
        // .catch(error => alert(error.message))



        if(`${email}` in localStorage){
            var checkPass = JSON.parse(localStorage.getItem(`${email}`));
            if(password==checkPass.password){
                if(checkPass.role==role){
                    localStorage.setItem('user',email);
                    if(checkPass.role=='user'){
                        history.push('/');
                    }
                    else{
                        console.log()
                        window.location.href='/admin/dashboard'
                    }
                }else{
                    alert('Oops!! It looks like you are trying to get in, using another Role.');
                }
            }else{
                alert('Invalid Credentials');
            }
        }else{
            alert('No User Found with this E-Mail ID');
        }

        
    }


  /*  const register = e=>{
        e.preventDefault();

        auth.createUserWithEmailAndPassword(email, password).then((auth) =>{
            if(auth){
                history.push('/')
            }
        })
        .catch(error => alert(error.message))

        // Firebase register
    }
*/

    return (
        <div className="login">
            <Link to="/" className='logoContainer'>
                <img className="login__logo" 
                src={logoImage} alt="Logo"/>            
            </Link>

            <div className="login__container">
                <h1>Sign-in</h1>
                <form>
                    <h5>Login as</h5>
                    <select name="cars" id="cars" onChange={e => setRole(e.target.value)} className="loginDropDown">
                        <option value="user">User</option>
                        <option value="admin">Admin</option>
                    </select>

                    <h5>E-mail</h5>
                    <input type="text" value={email} onChange={e => setEmail(e.target.value)}/>
                    
                    <h5>Password</h5>
                    <input type="password" value={password} onChange={e => setPassword(e.target.value)}/>

                    <button type="submit" onClick={signIn} className="login__signInButton">Sign In </button>
                </form>

                <p>
                    By signing-in you agree to EPharma's Conditions of use & Sale. Please see our Privacy Notice, our Cookies Notice and our Interest-Based Ads Notice.
                </p>
                

                <div className='registerBtnContainer'>
                    <p className='alreadyRegistered'>
                        Don't have an account?
                    </p>

                    <Link to="/register" className='underlinedLink'>
                        <div className='registerDiv'>
                            Register
                        </div>
                    </Link>
                </div>
            </div>
        </div>
    )
}

export default Login