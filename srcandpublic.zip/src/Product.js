import React, { useState } from 'react';
import './Product.css';
import StarIcon from '@material-ui/icons/Star';
import { useStateValue } from './StateProvider';

function Product({ id, title, image, price, rating }) {
    const [ {basket}, dispatch ] = useStateValue();
    const [isActive, setActive] = useState(true);
      
    var basketItemCount = basket.length;
    console.log(basketItemCount);


    if(basketItemCount>=0){
        var showCart = true;
    }else{
        var showCart=false;
    }



    const addToBasket = () => {
        //dispatch the item into the data layer
        dispatch({
            type: 'ADD_TO_BASKET',
            item: {
                id: id,
                title: title,
                image: image,
                price: price,
                rating: rating,
            },
        });

        setActive(!isActive);
    };


    const addToBasketQuantity = () => {
        dispatch({
            type: 'ADD_TO_BASKET',
            item: {
                id: id,
                title: title,
                image: image,
                price: price,
                rating: rating,
            },
        });
    }

    const removeFromBasket = () => {
        dispatch({
            type:'REMOVE_FROM_BASKET',
            id: id,
        })

        if(basketItemCount==0){
            setActive(isActive);
        }   
    }

    return (
        <div className="product">
            <div className="product__info">
                <p>{title}</p>
                <p className="product__price">
                    <small>₹</small>
                    <strong>{price}</strong>
                </p>

                <div className="product__rating">
                    {Array(rating).fill().map((_, i)=>(
                        <StarIcon className="product__star"/>
                    ))}
                </div> 
            </div>

            <img src={image} alt="" />
            <div className={!isActive ? 'addToCartBtnContainer': 'hideBtnBasket'}>
                <button onClick={removeFromBasket} className='btnItem'>-</button>
                <p className="quantity">Quantity</p>
                <button onClick={addToBasketQuantity} className='btnItem'>+</button>
            </div>
            
            <button onClick={addToBasket} className={isActive ? 'btnBasket': 'hideBtnBasket'}>Add to Basket</button>
        </div>
    );
}

export default Product;