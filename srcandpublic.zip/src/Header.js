import React from 'react';
import SearchIcon from '@material-ui/icons/Search';
import ShoppingBasketIcon from '@material-ui/icons/ShoppingBasket';
import LocationOnIcon from '@material-ui/icons/LocationOn';
import MenuIcon from '@material-ui/icons/Menu';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import { Box } from '@material-ui/core';
import './Header.css';
import { Link } from 'react-router-dom';
import { useStateValue } from './StateProvider';
// import { auth} from './firebase';
import logoImage from './images/log.png';


function Header() {
    const [{ basket, user }] = useStateValue();

    if('user' in localStorage){
        var userInfo = localStorage.getItem('user');
        var userDetails = JSON.parse(localStorage.getItem(userInfo));
        var userName = (userDetails.name).split(' ');
        var userEmail = userName[0];
    }
    
    

    const handleAuthentication = () =>{
        // if(user){
        //     auth.signOut();
        // }

        if('user' in localStorage){
            localStorage.removeItem('user');
            userEmail='';
            
            window.location.reload();
        }
    }


    return (
        <div className="header" id="header">

            <Link to="/" className="logo__container">
                <img src={logoImage} alt="" className="header__logo" />
            </Link>
            {/* Logo */}
            
            
            
            {/* Delivery Address */}
            <div className="header__deliverLoc">
                <p className='deliveryAddress'>Deliver to {userEmail}</p>
                <div className="loc__icon">
                    <LocationOnIcon className="navigation"/>
                    <span>Jabalpur, 482004</span>
                </div>
            </div>


            {/* Search Bar */}
            <div className="header__search">
                <input className="header__searchInput" type="text" onBlur={(e)=>{alert(e.target.value)}}/>                
                <SearchIcon className="header__searchIcon" />
            </div>


            {/* Navbar Options */}
            <div className="header__nav">
                <Link to={!userEmail && "/login"} className='header_underlined'>
                    <div onClick={handleAuthentication}  className="header__option">
                        <span className="header__optionLineOne">Hello, {userEmail ? userEmail : 'Guest'}</span>
                        <span className="header__optionLineTwo">{userEmail ? 'Sign Out' : 'Sign In'}</span>
                    </div>
                </Link>

                <div className="header__option">
                    <span className="header__optionLineOne">Return &</span>
                    <span className="header__optionLineTwo">Orders</span>
                </div>

                {/* <div className="header__option">
                    <span className="header__optionLineOne">Your</span>
                    <span className="header__optionLineTwo">Prime</span>
                </div> */}

                <Link to="/checkout">
                    <div className="header__optionBasket">
                        <ShoppingBasketIcon className="header__optionLineOne"/>
                        <span className="header_optionLineTwo header_basketCount">{basket?.length}</span>
                    </div>                        
                </Link>

                <Box className="exitIcon">
                    <Link to={!user && "/login"}>
                        <div onClick={handleAuthentication}  className="header__option">                        
                            
                                <ExitToAppIcon className="header__exitIcon" />
                                <span className="header__optionLineTwo">{user ? 'Sign Out' : 'Sign In'}</span>
                        </div>
                    </Link>
                </Box>
            </div>
            
            

        </div>
    )
}

export default Header