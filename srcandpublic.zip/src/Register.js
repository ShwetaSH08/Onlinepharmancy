import React, { useState} from 'react';
import './Register.css';
import { Link, useHistory } from 'react-router-dom';
import logoImage from './images/log.png';

function Register() {
    const history = useHistory()
    const [email, setEmail] = useState('');
    const [name, setName] = useState('');
    const [password, setPassword] = useState('');
    const [mobileNumber, setMobileNumber] = useState('');
    const [role, setRole] = useState('user');
    const [gender, setGender] = useState('male');


    const maxLengthCheck = (object) => {
        if (object.target.value.length > object.target.maxLength) {
            object.target.value = object.target.value.slice(0, object.target.maxLength)
        }
    }


    const signUp = e =>{
        e.preventDefault();

        if(email!='' && password!='' && mobileNumber!='' && name!=''){
            const registerCreds ={
                'email':email,
                'role':role,
                'password':password,
                'name':name,
                'mobileNumber':mobileNumber,
                'gender':gender
            }

            localStorage.setItem(`${email}`, JSON.stringify(registerCreds));
            localStorage.setItem('user',email);

            history.push('/login');
        }else{
            alert('Fill in all the required fields');
        }
        
    }

  return (
    <div className="signup">
        <Link to="/">
            <img className="login__logo" 
            src={logoImage} alt="Logo"/>            
        </Link>
            
        <div className="signup__container">
            <h1>Sign-Up</h1>
            <form>
                <h5>Sign Up as</h5>
                <select name="roles" id="roles" onChange={e => setRole(e.target.value)} className="loginDropDown">
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                </select>

                <div className='nameEmailContainer'>
                    <div>
                        <h5>Name</h5>
                        <input type="text" value={name} onChange={e => setName(e.target.value)} required/>
                    </div>
                    
                    <div>
                        <h5>E-mail</h5>
                        <input type="text" value={email} onChange={e => setEmail(e.target.value)} required/>
                    </div>
                </div>
                
                
                <h5>Password</h5>
                <input type="password" value={password} maxLength={15} onChange={e => setPassword(e.target.value)} required/>

                <h5>Mobile Number</h5>
                <input type="number"  maxLength="10" onInput={maxLengthCheck} value={mobileNumber} onChange={e => setMobileNumber(e.target.value)} required/>

                
                <h5>Gender</h5>
                <div className='genOpt'>
                    <div className='genderMF'>
                        <input type="radio" onChange={e => setGender(e.target.value)}
                               id="male" name="gender" value="male" />
                        <label for="male" className='gLabels'>Male</label>
                    </div>
                    
                    <div className='genderMF'>
                        <input type="radio" onChange={e => setGender(e.target.value)}
                               id="female" name="gender" value="gender" />
                        <label for="female" className='gLabels'>Female</label>
                    </div>
                </div>

                <button type="submit" onClick={signUp} className="login__signUpButton">Create Account</button>
            </form>

        
            <p className='option'>
                Or
            </p>


            <div className='loginBtnContainer'>
                <p className='alreadyRegistered'>
                    Already have an account?
                </p>

                <Link to="/login" className='underlinedLink'>
                    Login
                </Link>
            </div>

        </div>
    </div>
  )
}

export default Register